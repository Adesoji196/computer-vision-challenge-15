//
//  ContentView.swift
//  challenge 15
//
//  Created by Turma02-1 on 05/11/26.
//

import SwiftUI
import PhotosUI
import AVFoundation
import UIKit
import Vision

struct ContentView: View {
    
    @State private var photoPicked: PhotosPickerItem?
    let sintetizador = AVSpeechSynthesizer()
    @State var imageToAnalise: UIImage?
    @State var detectedText: String = ""
    
    @MainActor func detectText(photo: UIImage?) async {
        let request = RecognizeDocumentsRequest()
        guard let image = photo else { return }
        guard let cgImage = image.cgImage else { return }
        let result = try? await request.perform(on: cgImage)
        
        guard let document = result?.first?.document else { return }
        let text = document.text.transcript
        detectedText = text
    }
    
    var body: some View {
        
        if let image = imageToAnalise {
            Image(uiImage: image)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .padding()
        }
        
        ScrollView {
            Text(detectedText)
        }
        
        PhotosPicker(selection: $photoPicked, matching: .images, photoLibrary: .shared()) {
            Text("Pegar da Galeria")
                .font(.headline)
                .padding()
                .frame(maxWidth: .infinity)
                .background(Color.indigo)
                .foregroundStyle(.white)
                .cornerRadius(25)
                .padding(.horizontal)
        }
        .onChange(of: photoPicked) { oldValue, newValue in
            if let newPhoto = newValue {
                Task {
                    if let data = try? await newPhoto.loadTransferable(type: Data.self),
                       let image = UIImage(data: data) {
                        
                        imageToAnalise = image
                    }
                }
            }
        }
        
        Button("Analisar o texto") {
            Task {
                await detectText(photo: imageToAnalise)
            }
        }
        
        Button("Listen to the Text") {
            let enuciado = AVSpeechUtterance(string: detectedText)
            enuciado.voice = AVSpeechSynthesisVoice(language: "pt-BR")
            enuciado.rate = 0.3
            sintetizador.speak(enuciado)
        }
    }
}

#Preview {
    ContentView()
}
