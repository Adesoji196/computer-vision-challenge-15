//
//  challenge_15App.swift
//  challenge 15
//
//  Created by Turma02-1 on 05/11/26.
//

import SwiftUI

@main
struct challenge_15App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
